// A header file for helpers.c
// Declare any additional functions in this file
